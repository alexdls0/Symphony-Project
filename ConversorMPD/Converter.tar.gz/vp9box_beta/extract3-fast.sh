#!/bin/bash

MYDIR=$(dirname $(readlink -f ${BASH_SOURCE[0]}))
SAVEDIR=$(pwd)

# Check programs
if [ -z "$(which ffmpeg)" ]; then
    echo "Error: ffmpeg is not installed"
    sleep 3
    exit 1
fi

cd "$MYDIR"

TARGET_FILES=$(find ./ -maxdepth 1 -type f \( -name "*.mov" -or -name "*.mp4" -or -name "*.mkv" \))
for f in $TARGET_FILES
do
  fe=$(basename "$f") # fullname of the file
  f="${fe%.*}" # name without extension

  if [ ! -d "${f}" ]; then #if directory does not exist, convert
    echo "Converting \"$f\" to multi-bitrate dual-audio HLS"
    sleep 2
    echo "Creating output directory \"$f\""
    sleep 1
    mkdir "${f}"

    echo "Creating audio streams for \"$f\""
    sleep 1
    #Audio streams (Opus VBR)
    ffmpeg -y -i "${fe}" -vn -sn -dn -acodec libopus -dash 1 -ab 192k -ac 2 -map 0:a:0 vp9_audio1.webm
    ffmpeg -y -i "${fe}" -vn -sn -dn -acodec libopus -dash 1 -ab 192k -ac 2 -map 0:a:1 vp9_audio2.webm

    echo "Creating video streams for \"$f\""
    sleep 1
    #Video streams
    ffmpeg -i "${fe}" -strict -2 -an -sn -dn -vf "scale=w=640:h=360:force_original_aspect_ratio=decrease" -c:v libvpx-vp9 -profile:v 0 -keyint_min 72 -g 72 -tile-columns 4 -frame-parallel 1 -row-mt 1 -threads 8 -deadline realtime -cpu-used 8 -auto-alt-ref 1 -dash 1 -lag-in-frames 25 -pix_fmt yuv420p -b:v 300k -y vp9_360p_300.webm
    ffmpeg -i "${fe}" -strict -2 -an -sn -dn -vf "scale=w=858:h=480:force_original_aspect_ratio=decrease" -c:v libvpx-vp9 -profile:v 0 -keyint_min 72 -g 72 -tile-columns 4 -frame-parallel 1 -row-mt 1 -threads 8 -deadline realtime -cpu-used 8 -auto-alt-ref 1 -dash 1 -lag-in-frames 25 -pix_fmt yuv420p -b:v 500k -y vp9_480p_500.webm
    #ffmpeg -i "${fe}" -strict -2 -an -sn -vf "scale=w=1280:h=720:force_original_aspect_ratio=decrease" -c:v libvpx-vp9 -profile:v 0 -keyint_min 72 -g 72 -tile-columns 4 -frame-parallel 1 -row-mt 1 -threads 8 -deadline realtime -cpu-used 8 -auto-alt-ref 1 -lag-in-frames 25 -pix_fmt yuv420p -b:v 1500k -y vp9_720p_1500.webm
    #ffmpeg -i "${fe}" -strict -2 -an -sn -vf "scale=w=1920:h=1080:force_original_aspect_ratio=decrease" -c:v libvpx-vp9 -profile:v 0 -keyint_min 72 -g 72 -tile-columns 4 -frame-parallel 1 -row-mt 1 -threads 8 -deadline realtime -cpu-used 8 -auto-alt-ref 1 -lag-in-frames 25 -pix_fmt yuv420p -b:v 3000k -y vp9_1080p_3000.webm

    echo "Creating HLS structure for \"$f\""
    sleep 1

    pkgr=''
    if [ -e "vp9_audio1.webm" ]; then
      pkgr+='in=vp9_audio1.webm,stream=audio,output='${f}'/audio1/vp9_audio1.webm '
    fi

    if [ -e "vp9_audio2.webm" ]; then
      pkgr+='in=vp9_audio2.webm,stream=audio,output='${f}'/audio2/vp9_audio2.webm '
    fi

    ./packager ${pkgr}'input=vp9_360p_300.webm,stream=video,output='${f}'/vp9_360p/vp9_360p_300.webm' \
    'input=vp9_480p_500.webm,stream=video,output='${f}'/vp9_480p/vp9_480p_500.webm' --mpd_output "${f}/${f}_master.mpd"
    
    echo "Cleaning up \"$f\""
    rm vp9_360p_300.webm vp9_480p_500.webm vp9_720p_1500.webm vp9_1080p_3000.webm vp9_audio1.webm vp9_audio2.webm

  fi

done

cd "$SAVEDIR"