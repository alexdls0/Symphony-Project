#!/bin/bash

MYDIR=$(dirname $(readlink -f ${BASH_SOURCE[0]}))
SAVEDIR=$(pwd)

# Check programs
if [ -z "$(which ffmpeg)" ]; then
    echo "Error: ffmpeg is not installed"
    sleep 3
    exit 1
fi

cd "$MYDIR"

TARGET_FILES=$(find ./ -maxdepth 1 -type f \( -name "*.mov" -or -name "*.mp4" -or -name "*.mkv" \))
for f in $TARGET_FILES
do
  fe=$(basename "$f") # fullname of the file
  f="${fe%.*}" # name without extension

  if [ ! -d "${f}" ]; then #if directory does not exist, convert
    echo "Converting \"$f\" to multi-bitrate multi-audio MPD"
    sleep 2
    echo "Creating output directory \"$f\""
    sleep 1
    mkdir "${f}"

    echo "Creating audio streams for \"$f\""
    sleep 1
    #Audio streams
    ffmpeg -y -i "${fe}" -vn -sn -dn -c:a aac -b:a 192k -map 0:a:0 "h264_audio1.m4a"
    ffmpeg -y -i "${fe}" -vn -sn -dn -c:a aac -b:a 192k -map 0:a:1 "h264_audio2.m4a"
    ffmpeg -y -i "${fe}" -vn -sn -dn -c:a aac -b:a 192k -map 0:a:2 "h264_audio3.m4a"
    ffmpeg -y -i "${fe}" -vn -sn -dn -c:a aac -b:a 192k -map 0:a:3 "h264_audio4.m4a"
    ffmpeg -y -i "${fe}" -vn -sn -dn -c:a aac -b:a 192k -map 0:a:4 "h264_audio5.m4a"
    ffmpeg -y -i "${fe}" -vn -sn -dn -c:a aac -b:a 192k -map 0:a:5 "h264_audio6.m4a"
    ffmpeg -y -i "${fe}" -vn -sn -dn -c:a aac -b:a 192k -map 0:a:6 "h264_audio7.m4a"

    echo "Creating video streams for \"$f\""
    sleep 1
    #Video streams
    ffmpeg -i "${fe}" -sn -an -dn -vf "scale=-2:360" -c:v libx264 -preset slow -profile:v baseline -level:v 3.0 -pix_fmt yuv420p -x264-params scenecut=0:open_gop=0:min-keyint=72:keyint=72 -crf 23 -minrate 600k -maxrate 600k -bufsize 600k -b:v 600k -y h264_baseline_360p_600.mp4
    ffmpeg -i "${fe}" -sn -an -dn -vf "scale=-2:480" -c:v libx264 -preset slow -profile:v main -level:v 3.1 -pix_fmt yuv420p -x264-params scenecut=0:open_gop=0:min-keyint=72:keyint=72 -crf 23 -minrate 1000k -maxrate 1000k -bufsize 1000k -b:v 1000k -y h264_main_480p_1000.mp4
    ffmpeg -i "${fe}" -sn -an -dn -vf "scale=-2:720" -c:v libx264 -preset slow -profile:v main -level:v 4.0 -pix_fmt yuv420p -x264-params scenecut=0:open_gop=0:min-keyint=72:keyint=72 -crf 22 -minrate 3000k -maxrate 3000k -bufsize 3000k -b:v 3000k -y h264_main_720p_3000.mp4
    ffmpeg -i "${fe}" -sn -an -dn -vf "scale=-2:1080" -c:v libx264 -preset slow -profile:v high -level:v 4.2 -pix_fmt yuv420p -x264-params scenecut=0:open_gop=0:min-keyint=72:keyint=72 -crf 21 -minrate 6000k -maxrate 6000k -bufsize 6000k -b:v 6000k -y h264_high_1080p_6000.mp4
    
    echo "Creating MPD structure for \"$f\""
    sleep 1
    pkgr=''
    if [ -e "h264_audio1.m4a" ]; then
      pkgr+='in=h264_audio1.m4a,stream=audio,output='${f}'/audio1/h264_audio1.m4a '
    fi

    if [ -e "h264_audio2.m4a" ]; then
      pkgr+='in=h264_audio2.m4a,stream=audio,output='${f}'/audio2/h264_audio2.m4a '
    fi

    if [ -e "h264_audio3.m4a" ]; then
      pkgr+='in=h264_audio3.m4a,stream=audio,output='${f}'/audio3/h264_audio3.m4a '
    fi

    if [ -e "h264_audio4.m4a" ]; then
      pkgr+='in=h264_audio4.m4a,stream=audio,output='${f}'/audio4/h264_audio4.m4a '
    fi

    if [ -e "h264_audio5.m4a" ]; then
      pkgr+='in=h264_audio5.m4a,stream=audio,output='${f}'/audio5/h264_audio5.m4a '
    fi

    if [ -e "h264_audio6.m4a" ]; then
      pkgr+='in=h264_audio6.m4a,stream=audio,output='${f}'/audio6/h264_audio6.m4a '
    fi

    if [ -e "h264_audio7.m4a" ]; then
      pkgr+='in=h264_audio7.m4a,stream=audio,output='${f}'/audio6/h264_audio7.m4a '
    fi

    ./packager ${pkgr}'in=h264_baseline_360p_600.mp4,stream=video,output='${f}'/h264_360p/h264_baseline_360p_600.mp4' \
    'in=h264_main_480p_1000.mp4,stream=video,output='${f}'/h264_480p/h264_main_480p_1000.mp4' \
    'in=h264_main_720p_3000.mp4,stream=video,output='${f}'/h264_720p/h264_main_720p_3000.mp4' \
    'in=h264_high_1080p_6000.mp4,stream=video,output='${f}'/h264_1080p/h264_high_1080p_6000.mp4' \
    --mpd_output "${f}/${f}_master.mpd"

    echo "Cleaning up \"$f\""
    rm h264_baseline_360p_600.mp4 h264_main_480p_1000.mp4 h264_main_720p_3000.mp4 h264_high_1080p_6000.mp4 h264_audio1.m4a h264_audio2.m4a h264_audio3.m4a h264_audio4.m4a h264_audio5.m4a h264_audio6.m4a h264_audio7.m4a

  fi

done

cd "$SAVEDIR"